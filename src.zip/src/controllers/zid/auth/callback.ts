// @ts-nocheck
import {ZidApiService} from "../../../services/zid-service";
export const zidAuthCallback = async (req, res) => {
    try {
        console.log('Received callback with query:', req.query);
        const zidCode = req.query.code;
        
        if (!zidCode) {
            console.error('No code received in callback');
            return res.status(400).json({ error: 'No authorization code received' });
        }
        
        console.log('Attempting to get tokens with code:', zidCode);
        const merchantTokens = await ZidApiService.getTokensByCode(zidCode);
        
        console.log('Received tokens:', JSON.stringify(merchantTokens, null, 2));
        
        // Check if the response contains an error
        if (merchantTokens.status === 'error') {
            console.error('Error in token response:', merchantTokens.message);
            return res.status(400).json({ error: 'Failed to obtain access token' });
        }

        // Now we can safely access the token properties
        const managerToken = merchantTokens.access_token;
        const authToken = merchantTokens.authorization;
        const refreshToken = merchantTokens.refresh_token;

        if (!managerToken || !authToken || !refreshToken) {
            console.error('Missing required tokens in response');
            return res.status(400).json({ error: 'Incomplete token information received' });
        }

        console.log('Successfully retrieved all required tokens');

        // Rest of your code...
        let user = await UserService.getUserByZidToken(managerToken);
        
        if (!user) {
            console.log('No existing user found, creating new user');
            const zidMerchantDetails = await ZidApiService.getMerchantProfile(managerToken, authToken);
            user = await UserService.createUserFromZidDetails(zidMerchantDetails, managerToken, authToken, refreshToken);
            console.log('New user created:', user.id);
        } else {
            console.log('Existing user found, updating tokens');
            await UserService.updateUserTokens(user.id, managerToken, authToken, refreshToken);
            console.log('User tokens updated for user:', user.id);
        }

        // Set session or JWT token here if you're using session-based or token-based authentication
        // For example:
        // req.session.userId = user.id;
        
        console.log('Redirecting to dashboard');
        // Redirect the user to your application dashboard.
        return res.redirect(process.env.DASHBOARD_URL);
    } catch (error) {
        console.error('Error in Zid auth callback:', error);
        return res.status(500).json({ error: 'Authentication failed', details: error.message });
    }
};